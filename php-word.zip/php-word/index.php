<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Advanced Contact Form with File Uploader">
	<meta name="author" content="UWS">
	<title>word generator MTK</title>

	<!-- Favicon -->
	<link href="img/favicon.png" rel="shortcut icon">

	<!-- Google Fonts - Poppins -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">	

	<!-- Font Awesome CSS -->
	<link href="vendor/fontawesome/css/all.min.css" rel="stylesheet">

	<!-- Custom Font Icons -->
	<link href="vendor/icomoon/css/iconfont.min.css" rel="stylesheet">

	<!-- Vendor CSS -->
	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="vendor/dmenu/css/menu.css" rel="stylesheet">
	<link href="vendor/hamburgers/css/hamburgers.min.css" rel="stylesheet">
	<link href="vendor/mmenu/css/mmenu.min.css" rel="stylesheet">
	<link href="vendor/filepond/css/filepond.css" rel="stylesheet">
	
	<!-- Main CSS -->
	<link href="css/style.css" rel="stylesheet">

</head>

<body>

	<!-- Preloader -->
	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- Preloader End -->

	<!-- Page -->
	<div id="page">
		<!-- Sub Header -->
		<div class="sub-header">
			<div class="container">
				<h1>Generator word pe baza de template tokenizat MTK Consult</h1>
			</div>
		</div>
		<!-- Sub Header End -->

		<!-- Main -->
		<main>
			<!-- Contact  -->
			<div class="contact">
				<div class="container">
					<!-- Form -->
					<form method="POST" id="contactForm" name="contactForm" action="magic.php" enctype="multipart/form-data">
						<div class="row">
							<div class="col-lg-8" id="mainContent">
								<!-- Personal Details -->
								<div class="row box first">
									<div class="box-header">
										<h3><strong>1</strong>Detalii personale</h3>
										<!-- <p>Subtitle or short description can be set here.</p> -->
									</div>
									<div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="denumiresocietate" class="form-control" name="denumiresocietate" placeholder="Denumire societate" type="text"  />
										</div>
									</div>
                                    <div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="username" class="form-control" name="username" placeholder="Numele reprezentantului" type="text" data-parsley-pattern="^[a-zA-Z\s.]+$" required />
										</div>
									</div>
                                    <div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="sediu" class="form-control" name="sediu" placeholder="Sediu/adresa" type="text" required />
										</div>
									</div>
                                    <div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="cui" class="form-control" name="cui" placeholder="CIF/CUI" type="text" required />
										</div>
									</div>
                                    <div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="regcom" class="form-control" name="regcom" placeholder="Inregistrata la registrul comertului" type="text" required />
										</div>
									</div>
                                    <div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="telefon" class="form-control" name="telefon" placeholder="Telefon" type="tel" required />
										</div>
									</div>
									<div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="email" class="form-control" name="email" placeholder="Adresa de email" type="email" required />
										</div>
									</div>
									<!-- <div class="col-md-12 col-sm-12">
										<div class="form-group">
											<input id="phone" class="form-control" name="phone" placeholder="Enter Phone e.g.: +363012345" type="text" data-parsley-pattern="^\+{1}[0-9]+$" />
										</div>
									</div> -->
								</div>
								<!-- Personal Details End -->
								<!-- File Uploader -->
								<div class="row box">
									<div class="box-header">
										<h3><strong>2</strong>Document</h3>
										<p>Incarca documentul</p>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="file" name="fileToUpload" id="fileToUpload"/>
										</div>
									</div>
								</div>
								<!-- File Uploader End -->
								<!-- Submit-->
								<div class="row box">
									<div class="col-12">
										<div class="form-group">
											<button type="submit" name="submit" class="btn-form-func">
												<span class="btn-form-func-content">Genereaza</span>
												<span class="icon"><i class="fa fa-paper-plane" aria-hidden="true"></i></span>
											</button>
										</div>
									</div>
								</div>
								<!-- Submit -->
							</div>
						</div>
					</form>
					<!-- Form End -->
				</div>
			</div>
			<!-- Contact End -->
		</main>
		<!-- Main End -->

	</div>
	<!-- Page End -->

	<!-- Back to top button -->
	<div id="toTop"><i class="fa fa-chevron-up"></i></div>

	<!-- Vendor Javascript Files -->
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="vendor/easing/js/easing.min.js"></script>
	<script src="vendor/parsley/js/parsley.min.js"></script>
	<script src="vendor/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendor/theia-sticky-sidebar/js/ResizeSensor.min.js"></script>
	<script src="vendor/theia-sticky-sidebar/js/theia-sticky-sidebar.min.js"></script>
	<script src="vendor/mmenu/js/mmenu.min.js"></script>
	<script src="vendor/filepond/js/filepond-plugin-file-validate-size.js"></script>
	<script src="vendor/filepond/js/filepond-plugin-file-validate-type.js"></script>
	<script src="vendor/filepond/js/filepond.min.js"></script>

	<!-- Main Javascript File -->
	<script src="js/scripts.js"></script>

</body>

</html>
