<?php 
// $target_file = $_FILES["fileToUpload"]["name"];

// var_dump($target_file);
$rand_no = rand(111111, 999999);
$target_dir = "tmp/";
$target_file = $target_dir . $rand_no . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;

if (!file_exists($target_file)){
    move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
}



$fileName = "results_" . $rand_no . ".docx";

$folder   = "results_";
$full_path = $folder . '/' . $fileName;
 
try
{
    if (!file_exists($folder))
    {
        mkdir($folder);
    }       
         
    //Copy the Template file to the Result Directory
    copy($target_file, $full_path);
 
    // add calss Zip Archive
    $zip_val = new ZipArchive();
 
    //Docx file is nothing but a zip file. Open this Zip File
    if($zip_val->open($full_path) == true)
    {
        // In the Open XML Wordprocessing format content is stored.
        // In the document.xml file located in the word directory.
         
        $key_file_name = 'word/document.xml';
        $message = $zip_val->getFromName($key_file_name);                
                     
        $timestamp = date('d-M-Y H:i:s');
         
        // this data Replace the placeholders with actual values
        $message = str_replace("{numar}",      $rand_no,       $message);
        $message = str_replace("{data}",  date("m.d.y"),  $message);
        $message = str_replace("{denumiresocietate}",  $_POST['denumiresocietate'],  $message);
        $message = str_replace("{username}",  $_POST['username'],  $message);
        $message = str_replace("{sediu}",  $_POST['sediu'],  $message);
        $message = str_replace("{cui}",  $_POST['cui'],  $message);
        $message = str_replace("{regcom}",  $_POST['regcom'],  $message);
        $message = str_replace("{telefon}",  $_POST['telefon'],  $message);
        $message = str_replace("{email}",  $_POST['email'],  $message);
         
        //Replace the content with the new content created above.
        $zip_val->addFromString($key_file_name, $message);
        $zip_val->close();
    }
    ///Then download the zipped file.
header('Content-Type: application/zip');
header('Content-disposition: attachment; filename='.$full_path);
header('Content-Length: ' . filesize($full_path));
readfile($full_path);

}
catch (Exception $exc) 
{
    $error_message =  "Error creating the Word Document";
    var_dump($exc);
}